package com.KoiProject.Koi.Care.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KoiCareSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
